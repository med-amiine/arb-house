import asyncio
import structlog
from typing import List, Optional
from web3 import Web3
from tenacity import retry, stop_after_attempt, wait_exponential

from app.config import settings

logger = structlog.get_logger()

class BalanceSync:
    """Periodically syncs agent balances with vault contract"""
    
    VAULT_ABI = [
        {
            "inputs": [{"name": "balances", "type": "uint256[3]"}],
            "name": "syncBalances",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "lastSync",
            "outputs": [{"name": "", "type": "uint256"}],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "shouldRebalance",
            "outputs": [{"name": "", "type": "bool"}],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "agents",
            "outputs": [
                {"name": "adapter", "type": "address"},
                {"name": "creditLimit", "type": "uint256"},
                {"name": "currentBalance", "type": "uint256"},
                {"name": "active", "type": "bool"}
            ],
            "stateMutability": "view",
            "type": "function"
        }
    ]
    
    _instance = None
    last_sync: Optional[int] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, 'initialized'):
            self.w3 = Web3(Web3.HTTPProvider(settings.arb_rpc_url))
            self.vault = self.w3.eth.contract(
                address=Web3.to_checksum_address(settings.vault_address),
                abi=self.VAULT_ABI
            )
            self.keeper_account = self.w3.eth.account.from_key(settings.keeper_private_key)
            self.running = False
            self.initialized = True
            
    async def run(self):
        """Main sync loop"""
        logger.info("balance_sync_starting", interval=settings.sync_interval_seconds)
        self.running = True
        
        while self.running:
            try:
                await self._sync_balances()
                await self._check_rebalance()
                await asyncio.sleep(settings.sync_interval_seconds)
            except Exception as e:
                logger.error("balance_sync_error", error=str(e))
                await asyncio.sleep(30)  # Longer backoff on sync errors
    
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    async def _sync_balances(self):
        """Fetch agent balances and sync to vault"""
        balances = await self._fetch_agent_balances()
        
        logger.info("syncing_balances", balances=balances)
        
        tx = self.vault.functions.syncBalances(balances).build_transaction({
            'from': self.keeper_account.address,
            'nonce': self.w3.eth.get_transaction_count(self.keeper_account.address),
            'gas': 150000,
            'maxFeePerGas': self.w3.eth.max_fee_per_gas,
            'maxPriorityFeePerGas': self.w3.eth.max_priority_fee_per_gas
        })
        
        signed = self.w3.eth.account.sign_transaction(tx, settings.keeper_private_key)
        tx_hash = self.w3.eth.send_raw_transaction(signed.rawTransaction)
        
        receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=60)
        
        if receipt.status == 1:
            self.last_sync = int(asyncio.get_event_loop().time())
            logger.info("balances_synced",
                       tx_hash=tx_hash.hex(),
                       balances=balances)
        else:
            logger.error("balance_sync_failed", tx_hash=tx_hash.hex())
    
    async def _fetch_agent_balances(self) -> List[int]:
        """Fetch current balances from all 3 agents via Giza SDK"""
        # TODO: Implement actual Giza SDK calls
        # For now, return mock data or read from agent adapters
        
        balances = []
        for i in range(3):
            try:
                # Read from contract (last known balance)
                agent_data = self.vault.functions.agents(i).call()
                current_balance = agent_data[2]  # currentBalance
                
                # In production: query actual agent TVL via Giza SDK
                # actual_balance = await giza_client.get_agent_balance(i)
                
                balances.append(current_balance)
            except Exception as e:
                logger.error("fetch_agent_balance_failed", agent=i, error=str(e))
                balances.append(0)
        
        return balances
    
    async def _check_rebalance(self):
        """Check if rebalancing is needed"""
        try:
            should_rebal = self.vault.functions.shouldRebalance().call()
            
            if should_rebal:
                logger.info("rebalance_needed")
                await self._execute_rebalance()
                
        except Exception as e:
            logger.error("rebalance_check_failed", error=str(e))
    
    async def _execute_rebalance(self):
        """Execute rebalancing between agents"""
        logger.info("executing_rebalance")
        
        # Get current state
        agent_data = []
        total_deployed = 0
        for i in range(3):
            data = self.vault.functions.agents(i).call()
            agent_data.append(data)
            total_deployed += data[2]  # currentBalance
        
        if total_deployed == 0:
            return
            
        # Calculate target amounts based on weights
        targets = []
        for i in range(3):
            weight = await self._get_target_weight(i)
            target_amount = (total_deployed * weight) // 10000
            targets.append(target_amount)
        
        # Determine moves
        for i in range(3):
            current = agent_data[i][2]
            target = targets[i]
            
            if current > target * 1.05:  # 5% threshold
                excess = current - target
                logger.info("rebalance_withdraw", agent=i, amount=excess)
                # await giza_client.withdraw_from_agent(i, excess)
            elif current < target * 0.95:
                deficit = target - current
                logger.info("rebalance_deposit", agent=i, amount=deficit)
                # await giza_client.deposit_to_agent(i, deficit)
    
    async def _get_target_weight(self, agent_index: int) -> int:
        """Get target weight for agent from contract"""
        # Note: This would require a getter in the contract
        # For now, return equal weights
        return 3333 if agent_index < 2 else 3334
    
    def stop(self):
        self.running = False
