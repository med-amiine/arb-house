# Testnet Deployment Guide

## New Wallet Created for Testing

```
Address:    0xD8CDe62aCB881329EBb4694f37314b7bBA77EbDe
PrivateKey: 0xf83888b4427573315e9c51748182ad353c04c7831c9280ef5a5ece0ef5f66646
```

**⚠️ SECURITY**: This is a test wallet. Send only testnet ETH (Arbitrum Sepolia).

---

## Deployment Steps

### 1. Setup Environment

Create `packages/contracts/.env`:

```bash
# RPC (Arbitrum Sepolia)
ARB_SEPOLIA_RPC_URL=https://arb-sepolia.g.alchemy.com/v2/YOUR_KEY
ARB_RPC_URL=$ARB_SEPOLIA_RPC_URL

# Deployment keys
DEPLOYER_PRIVATE_KEY=0xf83888b4427573315e9c51748182ad353c04c7831c9280ef5a5ece0ef5f66646
KEEPER_ADDRESS=0xD8CDe62aCB881329EBb4694f37314b7bBA77EbDe

# Verification
ARBISCAN_API_KEY=your_arbiscan_api_key
```

### 2. Deploy Everything

```bash
cd packages/contracts
source .env

# Deploy USDC + 3 Agents + Vault
forge script script/DeployTestnet.s.sol \
  --rpc-url $ARB_SEPOLIA_RPC_URL \
  --broadcast \
  --verify
```

This deploys:
- MockUSDC (if not provided)
- 3 MockAgentAdapters (Aave, Pendle, Morpho strategies)
- BondCreditVault with agents configured

### 3. Save Deployment Addresses

After deployment, addresses are saved to:
`deployments/testnet-latest.json`

Example:
```json
{
  "usdc": "0x...",
  "vault": "0x...",
  "keeper": "0x...",
  "agents": [
    "0x...",
    "0x...",
    "0x..."
  ]
}
```

### 4. Update Frontend & Keeper

Add to `packages/frontend/.env.local`:
```bash
NEXT_PUBLIC_VAULT_ADDRESS=0x...
NEXT_PUBLIC_USDC_ADDRESS=0x...
NEXT_PUBLIC_CHAIN_ID=421614
NEXT_PUBLIC_RPC_URL=https://arb-sepolia.g.alchemy.com/v2/YOUR_KEY
NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID=your_project_id
```

Add to `packages/keeper/.env`:
```bash
ARB_RPC_URL=https://arb-sepolia.g.alchemy.com/v2/YOUR_KEY
CHAIN_ID=421614
KEEPER_PRIVATE_KEY=0xf83888b4427573315e9c51748182ad353c04c7831c9280ef5a5ece0ef5f66646
KEEPER_ADDRESS=0xD8CDe62aCB881329EBb4694f37314b7bBA77EbDe
VAULT_ADDRESS=0x...
```

---

## Testing Workflows

### Test 1: Deposit Flow

```bash
# Get some testnet USDC (from faucet or mint if using mock)
# Then deposit

cast send $VAULT_ADDRESS \
  "deposit(uint256,address)" \
  10000000000 \
  $YOUR_ADDRESS \
  --private-key $YOUR_KEY \
  --rpc-url $ARB_SEPOLIA_RPC_URL
```

### Test 2: Capital Deployment (Keeper)

```bash
# Deploy capital from vault to agents
source .env
export VAULT_ADDRESS=0x...

forge script script/DeployCapital.s.sol \
  --rpc-url $ARB_SEPOLIA_RPC_URL \
  --broadcast
```

### Test 3: Simulate Yield Injection

```bash
# Inject yield to test NAV updates
export VAULT_ADDRESS=0x...
export AGENT_0_ADDRESS=0x...
export AGENT_1_ADDRESS=0x...
export AGENT_2_ADDRESS=0x...

forge script script/SimulateYield.s.sol \
  --rpc-url $ARB_SEPOLIA_RPC_URL \
  --broadcast
```

### Test 4: Keeper Sync

After yield injection, keeper should:
1. Read actual balances from agents
2. Call `vault.syncBalances([agent0Bal, agent1Bal, agent2Bal])`
3. Share price updates automatically

### Test 5: Async Withdrawal

```bash
# Request withdrawal (burns shares)
cast send $VAULT_ADDRESS \
  "requestWithdraw(uint256)" \
  5000000000 \
  --private-key $YOUR_KEY \
  --rpc-url $ARB_SEPOLIA_RPC_URL

# Keeper monitors event, recalls from agents, completes withdrawal
cast send $VAULT_ADDRESS \
  "completeWithdrawal(address,uint256)" \
  $YOUR_ADDRESS \
  0 \
  --private-key $KEEPER_PRIVATE_KEY \
  --rpc-url $ARB_SEPOLIA_RPC_URL
```

---

## Expected Behavior

| Action | Expected Result |
|--------|-----------------|
| Deposit 1000 USDC | Receive ~1000 BCV shares |
| Deploy to agents | Keeper moves 90% to agents, 10% idle |
| Yield injection + sync | Share price increases (e.g., 1.00 → 1.05) |
| New deposit | Fewer shares issued at higher NAV |
| Request withdraw | Shares burned, USDC queued |
| Keeper completes | USDC sent to user, queue cleared |

---

## Verification Commands

```bash
# Check share price
cast call $VAULT_ADDRESS "convertToAssets(uint256)" 1000000 --rpc-url $ARB_SEPOLIA_RPC_URL

# Check TVL
cast call $VAULT_ADDRESS "totalAssets()" --rpc-url $ARB_SEPOLIA_RPC_URL

# Check agent balances
cast call $VAULT_ADDRESS "agents(uint256)" 0 --rpc-url $ARB_SEPOLIA_RPC_URL

# Check pending withdrawals
cast call $VAULT_ADDRESS "pendingAssets(address)" $YOUR_ADDRESS --rpc-url $ARB_SEPOLIA_RPC_URL
```

---

## Troubleshooting

**Issue**: Keeper can't sync balances
- Check keeper address matches `vault.keeper()`
- Verify keeper has ETH for gas

**Issue**: Yield not showing in share price
- Must call `syncBalances()` after yield injection
- Check `lastSync` timestamp

**Issue**: Withdrawal stuck
- Check keeper is running and monitoring events
- Verify agent has sufficient USDC to withdraw
