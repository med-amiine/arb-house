# Bond Credit Vault

Institutional-grade credit vault extending secured capital to autonomous AI agents.

## Architecture

| Layer | Tech | Host |
|-------|------|------|
| Smart Contracts | Solidity + Foundry | Arbitrum |
| Keeper | Python + FastAPI | Railway |
| Frontend | Next.js + TypeScript | Vercel |

## Quick Start

```bash
# Install dependencies
make install

# Run tests
make test

# Deploy contracts (local)
make deploy-local

# Start keeper (local)
make keeper-dev

# Start frontend (local)
make frontend-dev
```

## Environment Setup

Copy example files and fill in values:

```bash
cp packages/contracts/.env.example packages/contracts/.env
cp packages/keeper/.env.example packages/keeper/.env
cp packages/frontend/.env.local.example packages/frontend/.env.local
```

See [ENVIRONMENT.md](./docs/ENVIRONMENT.md) for full variable reference.

## Repository Structure

```
packages/
├── contracts/      # Foundry + Solidity
├── keeper/         # Python FastAPI service
└── frontend/       # Next.js + TypeScript
```

## License

MIT
